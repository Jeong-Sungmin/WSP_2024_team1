const express = require("express");
const path = require("path");

const app = express();

// Static 파일 서빙 설정
app.use(express.static(path.join(__dirname)));

// /home 경로로 HTML 파일 서빙
app.get("/home", (req, res) => {
  res.sendFile(path.join(__dirname, "testAboutMainScreen.html"));
});

// 기본 라우트
app.get("/", (req, res) => {
  res.send("Hello, Docker and Node.js!");
});

// 서버 실행
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
